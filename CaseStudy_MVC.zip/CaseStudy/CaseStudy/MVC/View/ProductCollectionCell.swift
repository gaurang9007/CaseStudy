//
//  ProductCollectionCell.swift
//  CaseStudy
//
//  Created by Gaurang Makawana on 18/07/17.
//  Copyright © 2017 Gaurang Makawana. All rights reserved.
//

import Foundation
import UIKit

class ProductCollectionCell: UICollectionViewCell {

    @IBOutlet weak var imgProduct: UIImageView!
}
