//
//  ProductDeliveryOptionCell.swift
//  CaseStudy
//
//  Created by Gaurang Makwana on 7/21/17.
//  Copyright © 2017 Gaurang Makawana. All rights reserved.
//

import Foundation
import UIKit

class ProductDeliveryOptionCell: UITableViewCell {
    
}
