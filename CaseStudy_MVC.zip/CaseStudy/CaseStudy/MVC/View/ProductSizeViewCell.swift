//
//  ProductSizeViewCell.swift
//  CaseStudy
//
//  Created by Gaurang Makwana on 7/21/17.
//  Copyright © 2017 Gaurang Makawana. All rights reserved.
//

import Foundation
import UIKit

protocol ProductQuantityDelegate {
    
    func selectedQuantity(quantity: String)
}


class ProductSizeViewCell: UITableViewCell {
    
    @IBOutlet weak var productTagListView: TagListView!
    @IBOutlet weak var btnAddBag: UIButton!
    
    @IBOutlet weak var pickerQuantity: CustomePickerView!
    
    var delegate:ProductQuantityDelegate?
    var quantityData = [String]()
    var maxQuantity: Int64 = 0
    
    var responseDict: [String: AnyObject]? = nil
    
    /*!
     @function    configureCell
     @abstract    This function is used to do the basic configuration of the tableviewcell.
     */
    func configureCell() {
        
        if self.quantityData.count > 0 {
            self.quantityData.removeAll()
        }
        
        for i in 1..<self.maxQuantity+1 {
            self.quantityData.append(String(i))
        }
        configPicker(picker: pickerQuantity, stringData: self.quantityData)
    }
    
    // MARK:
    // MARK: - Custom PickerView Methods
    // MARK:
    
    func configPicker(picker : CustomePickerView,stringData : [String] ) {
        
        picker.pickerType = .StringPicker
        //let stringData = ["AVFoundation","Accelerate","AddressBook","AddressBookUI","AssetsLibrary"]
        picker.stringPickerData = stringData
        picker.pickerRow.font = UIFont(name: "American Typewriter", size: 30)
        picker.toolbar.barTintColor = .darkGray
        picker.toolbar.tintColor = .black
        
        picker.stringDidChange = { (index) in
            
            print("selectedString ", self.quantityData[index])
            self.delegate?.selectedQuantity(quantity: self.quantityData[index])
        }
    }
    
    /*!
     @function    configureSizeCell
     @abstract    This function is used to initialize the size values and enable/disable the size option.
     */

    func configureSizeCell(availableSizeArray:[ProductSize], delegate:ProductDetailViewController) {
        
        if availableSizeArray.count > 0 {
            
            productTagListView.delegate = delegate
            productTagListView.textFont = UIFont.systemFont(ofSize: 15)
            productTagListView.shadowRadius = 2
            productTagListView.shadowOpacity = 0.4
            productTagListView.shadowColor = UIColor.black
            productTagListView.shadowOffset = CGSize(width: 1, height: 1)
            for productSizeDict in availableSizeArray {
                let sizeName = productSizeDict.size
                productTagListView.addTag(sizeName!)
            }
            productTagListView.alignment = .left
            
        } else { print("No sizes available") }
        
        if self.responseDict != nil {
            
            let dictStocks = responseDict?["stock"] as? [String: AnyObject]
            let maxQuantity = dictStocks?["maxAvailableQty"] as! Int64
            let sizeCode = responseDict?["sizeCode"] as! String
            
            for subview in self.productTagListView.tagViews {
                
                subview.isEnabled = true
                if subview.currentTitle == sizeCode {
                    if maxQuantity == 0 {
                        subview.isEnabled = false
                    } else {
                        subview.isSelected = true
                    }
                } else {
                    let maxQuantity = delegate.getProductQuantityBySize(productSize: subview.currentTitle!)
                    if maxQuantity == 0 {
                        subview.isEnabled = false
                    }
                }
            }
        }
    }
}
