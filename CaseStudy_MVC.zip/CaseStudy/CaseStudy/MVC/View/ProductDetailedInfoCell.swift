//
//  ProductDetailedInfoCell.swift
//  CaseStudy
//
//  Created by Gaurang Makwana on 7/21/17.
//  Copyright © 2017 Gaurang Makawana. All rights reserved.
//

import Foundation
import UIKit

class ProductDetailedInfoCell: UITableViewCell {
    
    @IBOutlet weak var segmentOptions: UISegmentedControl!
    @IBOutlet weak var txtDescription: UITextView!
    
    var responseDict: [String: AnyObject]? = nil
    
    /*!
     @function    configureCell
     @abstract    This function is used to do the basic configuration of the tableviewcell.
     */
    func configureCell() {
        
        if responseDict != nil {
            updateUI()
        }
    }
    
    /*!
     @function    updateUI
     @abstract    This function is used to update the value based on the selected option.
     */
    func updateUI() {
        
        if segmentOptions.selectedSegmentIndex == SegmentOption.Description.rawValue {
             self.txtDescription.attributedText = appDelegate.stringFromHtml(string: (responseDict?["description"] == nil || responseDict?["description"] is NSNull) ? "" :  responseDict?["description"] as! String)
        
        } else if segmentOptions.selectedSegmentIndex == SegmentOption.TechSpec.rawValue {
            let colourValue = (responseDict?["color"] == nil || responseDict?["color"] is NSNull) ? "" :  responseDict?["color"] as! String
            let genderValue = (responseDict?["gender"] == nil || responseDict?["gender"] is NSNull) ? "" :  responseDict?["gender"] as! String
            self.txtDescription.text = String(format: "Colour:    %@ \nGender:    %@", colourValue, genderValue)
            
        } else {
            self.txtDescription.attributedText = appDelegate.stringFromHtml(string: "Delivery details goes here.")
        }
    }
    
    /*!
     @function    indexChanged
     @abstract    This function is called when user selected any section of the given options.
     */
    @IBAction func indexChanged(sender:UISegmentedControl) {
        
        switch segmentOptions.selectedSegmentIndex {
        case SegmentOption.Description.rawValue:
            self.txtDescription.attributedText = appDelegate.stringFromHtml(string: (responseDict?["description"] == nil || responseDict?["description"] is NSNull) ? "" :  responseDict?["description"] as! String)
        case SegmentOption.TechSpec.rawValue:
            
            let colourValue = (responseDict?["color"] == nil || responseDict?["color"] is NSNull) ? "" :  responseDict?["color"] as! String
            let genderValue = (responseDict?["gender"] == nil || responseDict?["gender"] is NSNull) ? "" :  responseDict?["gender"] as! String
            self.txtDescription.text = String(format: "Colour:    %@ \nGender:    %@", colourValue, genderValue)
            
        case SegmentOption.Delivery.rawValue:
            self.txtDescription.attributedText = appDelegate.stringFromHtml(string: "Delivery details goes here.")
        default:
            break;
        }
    }
}
