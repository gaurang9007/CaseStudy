//
//  ProductListCell.swift
//  CaseStudy
//
//  Created by Gaurang Makawana on 17/07/17.
//  Copyright © 2017 Gaurang Makawana. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
import SDWebImage

enum BackendError: Error {
    case urlError(reason: String)
    case objectSerialization(reason: String)
}

class ProductListCell: UITableViewCell {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var imgProduct: UIImageView!
    
    /*!
     @function    configureCell
     @abstract    This function is used to do the basic configuration of the tableviewcell.
     */
    func configureData(serverProduct:ServerProduct) {
        
        let imageURL = String(format:"%@%@", baseImageURL, serverProduct.image!)
        self.imgProduct.sd_setImage(with: URL(string: imageURL), placeholderImage: UIImage(named: "placeholder_cell"))
        
        self.lblName.text = serverProduct.name
        self.lblDescription.text = serverProduct.description
        self.lblDescription.attributedText = appDelegate.stringFromHtml(string: serverProduct.description!)
        self.lblPrice.text = serverProduct.price
    }
}

