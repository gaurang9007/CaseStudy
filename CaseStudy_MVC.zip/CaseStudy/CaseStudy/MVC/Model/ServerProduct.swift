//
//  ServerProduct.swift
//  CaseStudy
//
//  Created by Gaurang Makwana on 7/17/17.
//  Copyright © 2017 Gaurang Makawana. All rights reserved.
//

import Foundation

class ServerProduct {

    var productId: String?
    var name: String?
    var slug: String?
    var image: String?
    var smallImage:String?
    var thumbnail: String?
    var description: String?
    var price:String?
}
