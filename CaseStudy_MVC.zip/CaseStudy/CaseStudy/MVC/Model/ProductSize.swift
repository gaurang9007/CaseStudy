//
//  ProductSize.swift
//  CaseStudy
//
//  Created by Gaurang Makwana on 7/22/17.
//  Copyright © 2017 Gaurang Makawana. All rights reserved.
//

import Foundation

class ProductSize {
    
    var size: String?
    var maxQuantity: Int64?
    var ID: String?
}
