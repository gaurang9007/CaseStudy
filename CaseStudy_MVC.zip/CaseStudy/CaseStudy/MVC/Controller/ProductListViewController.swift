//
//  ProductListViewController.swift
//  CaseStudy
//
//  Created by Gaurang Makawana on 17/07/17.
//  Copyright © 2017 Gaurang Makawana. All rights reserved.
//

import Foundation
import UIKit
import Alamofire

class ProductListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableProductList: UITableView!
    @IBOutlet var lblMessage: UILabel!
    
    let kLoadingCellTag:Int = -1
    var currentPage:Int = 0
    var totalHits:Int = 0
    var totalPages:Int = 0
    var pageHits:Int = 20
    var isFetchingData:Bool = false
    
    var arrProductList:[ServerProduct] = []
    let tableViewListCellIdentifier :String = "ProductListCell"

    //MARK:- ViewLife Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Product List"
        self.tableProductList.addSubview(self.refreshControl)
        
        //Call webservice to get the product list
        getProductList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //Call function to initialize the UI part
        initializeController()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //MARK:-
    //MARK:- Initializer method
    //MARK:-
    
    /*!
     @function    initializeController
     @abstract    This function is used to initialize the UI part based on the available records.
     */
    func initializeController() {
        
        if arrProductList.count == 0 {
            tableProductList.isHidden = true
            lblMessage.isHidden = false
        } else {
            tableProductList.isHidden = false
            lblMessage.isHidden = true
        }
    }
    
    //MARK:-
    //MARK:- Refresh Control
    //MARK:-
    
    lazy var refreshControl: UIRefreshControl = {
        
        
        let refreshControl = UIRefreshControl()
        
        refreshControl.attributedTitle = NSAttributedString(string: "Fetching Product Data ...")
        refreshControl.addTarget(self, action: #selector(ProductListViewController.handleRefresh(_:)), for: UIControlEvents.valueChanged)
        refreshControl.tintColor = UIColor.red
        return refreshControl
    }()
    
    /*!
     @function    handleRefresh
     @abstract    This function is used to reset the page logic and fetch the first page records
     */
    func handleRefresh(_ refreshControl: UIRefreshControl) {
        
        // Reset the logic and call method to get the product list
        currentPage = 0
        getProductList()
        refreshControl.endRefreshing()
    }
    
    //MARK:-
    //MARK:- UITableView Methods
    //MARK:-
    
    func numberOfSections(in tableView: UITableView) -> Int  {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 140
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if currentPage == 0 {
            return 1;
        }
        
        if currentPage < totalPages {
            return self.arrProductList.count + 1;
        }
        return self.arrProductList.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row < self.arrProductList.count {
            
            let cell:ProductListCell = tableView.dequeueReusableCell(withIdentifier: self.tableViewListCellIdentifier, for: indexPath) as! ProductListCell
            let serverProduct:ServerProduct = self.arrProductList[indexPath.row]
            cell.configureData(serverProduct:serverProduct)
            cell.selectionStyle = UITableViewCellSelectionStyle.none
            return cell
        } else {
            return loadingCell();
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        if cell.tag == kLoadingCellTag {
            
            if !(isFetchingData) {
                getProductList()
            }
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.title = ""
        let productDetailVC = UIViewController.productDetailViewController()
        productDetailVC.serverProduct = self.arrProductList[indexPath.row]
        navigationController?.pushViewController(productDetailVC, animated: true)
    }
    
    //MARK:-
    //MARK:- Custom loding Cell
    //MARK:-
    
    /*!
     @function    loadingCell
     @abstract    This function is used to add the loading indicator when user loads the next page to fetch more records
     */
    func loadingCell() -> UITableViewCell {
        
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        for view in cell.contentView.subviews {
            view.removeFromSuperview()
        }
        let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .gray)
        var activityIndicatorFrame:CGRect = activityIndicator.frame
        activityIndicatorFrame.origin.y = (140-activityIndicatorFrame.height)/2.0
        activityIndicatorFrame.origin.x = UIScreen.main.bounds.width/2.0
        activityIndicator.frame = activityIndicatorFrame
        cell.contentView.addSubview(activityIndicator)
        activityIndicator.startAnimating()
        cell.tag = kLoadingCellTag
        return cell
    }
    
    //MARK:-
    //MARK:- WebService Call
    //MARK:-
    
    /*!
     @function    getProductList
     @abstract    This function is used to get the list of products based on searchString, page and hits
     */
    func getProductList() {
        
        if NetworkReachability.isInternetAvailable() == false {
            _ = SweetAlert().showAlert(appName, subTitle: "Please check internet connection!", style: AlertStyle.warning)
            return
        }
        
        self.isFetchingData = true
        appDelegate.showProgressHUD(message: "Please wait...")
        let searchString = "boy"
        let page = String(currentPage)
        let hits = String(pageHits)
        let strQueryString = String(format:"?searchString=%@&page=%@&hits=%@", searchString, page, hits)
        let serverURL = String(format:"%@%@%@", baseURL, productListAPI, strQueryString)
        
        Alamofire.request(serverURL, method: .post, parameters: nil, encoding: URLEncoding.default, headers: nil).responseJSON { (response:DataResponse<Any>) in
            
            self.isFetchingData = false
            
            switch(response.result) {
                
            case .success(_):
                if response.result.value  != nil{
                    
                    if self.currentPage == 0 {
                        if (self.arrProductList.count) > 0 {
                            self.arrProductList.removeAll()
                        }
                    }
                    self.currentPage += 1
                    self.parseData(JSONData: response.data!)
                }
            case .failure(_):
                
                appDelegate.hideProgressHUD()
                print(response.result.error ?? "error")
                break
            }
        }
    }
    
    //MARK:-
    //MARK:- Data Parsing
    //MARK:-
    
    func parseData(JSONData: Data) {
        
        do {
            let readableJSON = try JSONSerialization.jsonObject(with:JSONData, options:.allowFragments) as! [String: AnyObject]
            
            let items = readableJSON["hits"] as! [[String: AnyObject]]
            //print("items : \(items)")
            
            let pageDict = readableJSON["pagination"] as! [String:AnyObject]
            totalHits = pageDict["totalHits"]! as! Int
            totalPages = pageDict["totalPages"]! as! Int
            
            for dictItem:[String:AnyObject] in items {
                
                let serverProduct:ServerProduct = ServerProduct()
                serverProduct.productId = dictItem["productId"]?.stringValue
                serverProduct.name = (dictItem["name"] == nil || dictItem["name"] is NSNull) ? "" :  dictItem["name"] as! String
                serverProduct.slug = (dictItem["slug"] == nil || dictItem["slug"] is NSNull) ? "" :  dictItem["slug"] as! String
                serverProduct.image = (dictItem["image"] == nil || dictItem["image"] is NSNull) ? "" :  dictItem["image"] as! String
                serverProduct.smallImage = (dictItem["smallImage"] == nil || dictItem["smallImage"] is NSNull) ? "" :  dictItem["smallImage"] as! String
                serverProduct.thumbnail = (dictItem["thumbnail"] == nil || dictItem["thumbnail"] is NSNull) ? "" :  dictItem["thumbnail"] as! String
                serverProduct.description = (dictItem["description"] == nil || dictItem["description"] is NSNull) ? "" :  dictItem["description"] as! String
                serverProduct.price = dictItem["price"]?.stringValue
                arrProductList.append(serverProduct)
            }
            print("items : \(arrProductList.count)")
            initializeController()
            tableProductList.reloadData()
            appDelegate.hideProgressHUD()
        }
        catch {
            print(error)
        }
    }
}
