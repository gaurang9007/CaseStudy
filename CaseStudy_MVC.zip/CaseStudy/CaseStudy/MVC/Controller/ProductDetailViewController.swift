//
//  ProductDetailViewController.swift
//  CaseStudy
//
//  Created by Gaurang Makawana on 17/07/17.
//  Copyright © 2017 Gaurang Makawana. All rights reserved.
//

import Foundation
import UIKit
import Alamofire

class ProductDetailViewController: UITableViewController, TagListViewDelegate, ProductQuantityDelegate {

    var serverProduct:ServerProduct! = nil
    var responseDict: [String: AnyObject]? = nil
    
    var availableSizeArray:[ProductSize] = []
    var showSizeCell:Bool = false
    
    //MARK:-
    //MARK:- ViewLife Cycle
    //MARK:-
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        //self.tableView.estimatedRowHeight = UITableViewAutomaticDimension
        //self.tableView.rowHeight = UITableViewAutomaticDimension
        self.title = serverProduct.slug
        
        //Call webservice to get the product details by slug
        getProductDetails(slugName:serverProduct.slug!)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK:
    // MARK: UITableView Methods
    // MARK:
    
    override func numberOfSections(in tableView: UITableView) -> Int  {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 6
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.row == tableViewOption.ProductGalleryView.rawValue {
            return self.view.frame.size.width
        } else if indexPath.row == tableViewOption.ProductPriceView.rawValue {
            return 186
        } else if indexPath.row == tableViewOption.ProdcutSizeView.rawValue {
            return 220
        } else if indexPath.row == tableViewOption.ProdcutWishListView.rawValue {
            return 60
        } else if indexPath.row == tableViewOption.ProdcutDeliveryView.rawValue {
            return 95
        } else {
            return 258
        }
        //return UITableViewAutomaticDimension
    }
    
    /*
    override func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
            
        return UITableViewAutomaticDimension
    }
    */
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == tableViewOption.ProductGalleryView.rawValue {
            let cell:ProductGalleryCell = tableView.dequeueReusableCell(withIdentifier: "ProductGalleryCell", for: indexPath) as! ProductGalleryCell
            cell.responseDict = self.responseDict
            cell.configureCell()
            cell.selectionStyle = .none
            return cell
            
        } else if indexPath.row == tableViewOption.ProductPriceView.rawValue {
            let cell:ProductPriceCell = tableView.dequeueReusableCell(withIdentifier: "ProductPriceCell", for: indexPath) as! ProductPriceCell
            cell.responseDict = self.responseDict
            cell.configureCell()
            cell.selectionStyle = .none
            return cell
        
        } else if indexPath.row == tableViewOption.ProdcutSizeView.rawValue {
            let cell:ProductSizeViewCell = tableView.dequeueReusableCell(withIdentifier: "ProductSizeViewCell", for: indexPath) as! ProductSizeViewCell
            cell.btnAddBag.addTarget(self, action: #selector(self.btnAddBagClicked(_:)), for: UIControlEvents.touchUpInside)
            cell.responseDict = self.responseDict
            cell.configureSizeCell(availableSizeArray: self.availableSizeArray, delegate: self)
            cell.maxQuantity = getCurrentQuantity()
            cell.configureCell()
            cell.delegate = self
            configureBagCell(cell: cell)
            cell.selectionStyle = .none
            return cell
        } else if indexPath.row == tableViewOption.ProdcutWishListView.rawValue {
            let cell:ProductWishListCell = tableView.dequeueReusableCell(withIdentifier: "ProductWishListCell", for: indexPath) as! ProductWishListCell
            cell.configureCell()
            cell.selectionStyle = .none
            return cell
        } else if indexPath.row == tableViewOption.ProdcutDeliveryView.rawValue {
            
            let cell:ProductDeliveryOptionCell = tableView.dequeueReusableCell(withIdentifier: "ProductDeliveryOptionCell", for: indexPath) as! ProductDeliveryOptionCell
            cell.selectionStyle = .none
            return cell
    
        } else {
            let cell:ProductDetailedInfoCell = tableView.dequeueReusableCell(withIdentifier: "ProductDetailedInfoCell", for: indexPath) as! ProductDetailedInfoCell
            cell.responseDict = self.responseDict
            cell.configureCell()
            cell.selectionStyle = .none
            return cell
        }
    }
    
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
   
    //MARK:
    //MARK: Action Events
    //MARK:
    
    @IBAction func btnAddBagClicked(_ sender:UIButton) {
        _ = SweetAlert().showAlert(appName, subTitle: "Add to bag clicked.", style: AlertStyle.none)
    }
    
    //MARK:
    //MARK: WebService Call
    //MARK:
    
    /*!
     @function    getProductDetails
     @abstract    This function is used to get the product details based on selected slug.
     */
    func getProductDetails(slugName:String) {
        if NetworkReachability.isInternetAvailable() == false {
            _ = SweetAlert().showAlert(appName, subTitle: "Please check internet connection!", style: AlertStyle.warning)
            self.navigationController?.popToRootViewController(animated: true)
            return
        }
        
        appDelegate.showProgressHUD(message: "Please wait...")
        
        let strSlug = String(format:"?slug=%@", slugName)
        let serverURL = String(format:"%@%@%@", baseURL, productDetailAPI, strSlug)
        
        Alamofire.request(serverURL, method: .get, parameters: nil, encoding: URLEncoding.default, headers: nil).responseJSON { (response:DataResponse<Any>) in
            
            switch(response.result) {
                
            case .success(_):
                if response.result.value  != nil{
                
                    self.parseData(JSONData: response.data!)
                }
            case .failure(_):
                
                appDelegate.hideProgressHUD()
                print(response.result.error ?? "error")
                self.navigationController?.popToRootViewController(animated: true)
                break
            }
        }
    }
    
    //MARK:-
    //MARK:- Data Parsing
    //MARK:-
    
    func parseData(JSONData: Data) {
        
        do {
            let readableJSON = try JSONSerialization.jsonObject(with:JSONData, options:.allowFragments) as? [String: AnyObject]
            
            responseDict = readableJSON
            if responseDict == nil {
                self.navigationController?.popToRootViewController(animated: true)
                appDelegate.hideProgressHUD()
                return
            }
            
            let prouctIDArray = responseDict?["siblings"] as? [String]

            if (prouctIDArray?.count)! > 0 {
                self.showSizeCell = true
                
                for productID in prouctIDArray! {
                    
                    let productSize:ProductSize = ProductSize()
                    let relatedDict = self.responseDict?["relatedProductsLookup"]?[productID] as? [String: AnyObject]
                    let dictStocks = relatedDict?["stock"] as? [String: AnyObject]
                    
                    productSize.size = relatedDict?["sizeCode"] as? String
                    productSize.maxQuantity = dictStocks?["maxAvailableQty"] as? Int64
                    productSize.ID = productID
                    
                    self.availableSizeArray.append(productSize)
                }
                print(availableSizeArray)
            
            } else {
                self.showSizeCell = false
            }
            self.tableView.reloadData()
            
            let indexPath1 = IndexPath(item: 3, section: 0)
            self.tableView.reloadRows(at: [indexPath1], with: .none)
            let indexPath2 = IndexPath(item: 4, section: 0)
            self.tableView.reloadRows(at: [indexPath2], with: .none)
            
            appDelegate.hideProgressHUD()
        }
        catch {
            appDelegate.hideProgressHUD()
            self.navigationController?.popToRootViewController(animated: true)
            print(error)
        }
    }
    
    // MARK:
    // MARK: Custom function
    // MARK:

    /*!
     @function    configureBagCell
     @abstract    This function is used to configure the productsize cell to enable/disable AddToBag button.
     */
    func configureBagCell(cell: ProductSizeViewCell) {
        
        cell.btnAddBag.isEnabled = false
        if responseDict != nil {
            
            if showSizeCell {
                var isSizeSelected: Bool = false
                for subview in (cell.productTagListView.tagViews) {
                    
                    if subview.isSelected {
                        isSizeSelected = true
                        break
                    }
                }
                if (isSizeSelected && (cell.pickerQuantity.text != "")) {
                    cell.btnAddBag.isEnabled = true
                }
            } else {
                if cell.pickerQuantity.text != "" {
                    cell.btnAddBag.isEnabled = true
                }
            }
        }
    }
    
    /*!
     @function    getCurrentQuantity
     @abstract    This function is used to get the current product's quantity.
     */
    func getCurrentQuantity()  -> Int64 {
        var maxQuantity:Int64 = 0
        if responseDict != nil {
            
            let dictStocks = self.responseDict?["stock"] as? [String: AnyObject]
            maxQuantity = dictStocks?["maxAvailableQty"] as! Int64
        }
        return maxQuantity
    }
    
    /*!
     @function    getProductIDByName
     @abstract    This function is used to get the productId based on the given product size.
     */
    func getProductIDByName(name:String)  -> String {
        var productID:String = ""
        for productSizeDict in availableSizeArray {
            
            let sizeName = productSizeDict.size
            if name == sizeName {
                productID = productSizeDict.ID!
                break
            }
        }
        return productID
    }
    
    /*!
     @function    getProductQuantityByID
     @abstract    This function is used to get the product quantity based on the given productId.
     */
    func getProductQuantityByID(productID:String)  -> Int64 {
        var maxQuantity:Int64 = 0
        for productSizeDict in availableSizeArray {
            let ID = productSizeDict.ID
            if productID == ID {
                maxQuantity = productSizeDict.maxQuantity!
                break
            }
        }
        return maxQuantity
    }
    
    /*!
     @function    getProductQuantityBySize
     @abstract    This function is used to get the product quantity based on the given product size.
     */
    func getProductQuantityBySize(productSize:String)  -> Int64 {
        var maxQuantity:Int64 = 0
        for productSizeDict in availableSizeArray {
            let size = productSizeDict.size
            if productSize == size {
                maxQuantity = productSizeDict.maxQuantity!
                break
            }
        }
        return maxQuantity
    }
    
    /*!
     @function    updateSizeCellByQuantity
     @abstract    This function is used to update the status of product size based on the selected quantity.
     */
    func updateSizeCellByQuantity(selectedQuantity:Int64) {
        
        let sizeCell: ProductSizeViewCell = self.tableView.cellForRow(at: IndexPath(row: 2, section: 0)) as! ProductSizeViewCell
        for subview in sizeCell.productTagListView.tagViews {
            
            subview.isEnabled = true
            let maxQuantity = self.getProductQuantityBySize(productSize: subview.currentTitle!)
            if selectedQuantity > maxQuantity {
                subview.isEnabled = false
            }
        }
    }
    
    // MARK:
    // MARK: ProductQuantity Delegate
    // MARK:
    
    func selectedQuantity(quantity: String) {
        
        if showSizeCell {
            let selectedQuantity:Int64 = Int64(quantity)!
            updateSizeCellByQuantity(selectedQuantity: selectedQuantity)
        }
        let sizeCell: ProductSizeViewCell = self.tableView.cellForRow(at: IndexPath(row: 2, section: 0)) as! ProductSizeViewCell
        configureBagCell(cell: sizeCell)
    }

    // MARK:
    // MARK: TagListViewDelegate
    // MARK:
    
    func tagPressed(_ title: String, tagView: TagView, sender: TagListView) {
        
        print("Tag pressed: \(title), \(sender)")
        
        let priceCell: ProductPriceCell = self.tableView.cellForRow(at: IndexPath(row: 1, section: 0)) as! ProductPriceCell
        let productID = getProductIDByName(name: title)
        priceCell.updateProductID(productID: productID)

        let sizeCell: ProductSizeViewCell = self.tableView.cellForRow(at: IndexPath(row: 2, section: 0)) as! ProductSizeViewCell
        
        let quantity = getProductQuantityByID(productID: productID)
        sizeCell.maxQuantity = quantity
        sizeCell.configureCell()
        
        for subview in sizeCell.productTagListView.tagViews {
        
             if subview == tagView {
                if quantity == 0 {
                    tagView.isEnabled = false
                }
                tagView.isSelected = !tagView.isSelected
             } else {
                subview.isSelected = false
             }
        }
        configureBagCell(cell: sizeCell)
    }
    
    func tagRemoveButtonPressed(_ title: String, tagView: TagView, sender: TagListView) {
        print("Tag Remove pressed: \(title), \(sender)")
        sender.removeTagView(tagView)
    }
}

