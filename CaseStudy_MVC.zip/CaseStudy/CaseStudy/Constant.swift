//
//  Constant.swift
//  CaseStudy
//
//  Created by Gaurang Makawana on 17/07/17.
//  Copyright © 2017 Gaurang Makawana. All rights reserved.
//

import Foundation
import UIKit

//https://prod4.mnpcdn.ae/small_light(p=thmb,of=undefined)/pub/media/catalog/product

//https://prod4.mnpcdn.ae/pub/media/catalog/product/2/1/211106099_nocolor_fr.jpg

//Webservice URL
let baseImageURL: String = "https://prod4.mnpcdn.ae/pub/media/catalog/product"
let baseURL: String = "https://www.mamasandpapas.ae"
let productListAPI: String = "/search/full"
let productDetailAPI: String = "/product/findbyslug/"


//Application name
let appName:String = "CaseStudy"

//Application delegate object
let appDelegate = UIApplication.shared.delegate as! AppDelegate

enum SegmentOption: Int {

    case Description = 0
    case TechSpec = 1
    case Delivery = 2
}


enum tableViewOption: Int {
    
    case ProductGalleryView = 0
    case ProductPriceView = 1
    case ProdcutSizeView = 2
    case ProdcutWishListView = 3
    case ProdcutDeliveryView = 4
    case ProdcutDetailedInfoView = 5
    
}
